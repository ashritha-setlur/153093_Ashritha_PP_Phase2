##Please execute the following queries for the program to function without errors;

Create Table Customers
(c_name varchar2(20),
c_mobile_no number(10) Primary key,
c_balance number(10));


Create Table Transactions
(c_mobile_no number(10),
c_transactions varchar2(200));