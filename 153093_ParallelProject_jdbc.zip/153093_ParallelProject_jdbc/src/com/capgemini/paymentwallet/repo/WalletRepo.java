package com.capgemini.paymentwallet.repo;

import java.math.BigDecimal;
import java.util.List;

import com.capgemini.paymentwallet.bean.Customer;
import com.capgemini.paymentwallet.exception.InsufficientBalanceException;
import com.capgemini.paymentwallet.exception.InvalidInputException;

public interface WalletRepo {

	public boolean save(Customer customer);
	
	public Customer findOne(String mobileNo) throws InvalidInputException;
	
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InsufficientBalanceException, InvalidInputException;
	
	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException;
	
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientBalanceException, InvalidInputException;

	public List<String> showTransaction(String mobileNo) throws InvalidInputException;
	
}
