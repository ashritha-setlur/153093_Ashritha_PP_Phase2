package com.capgemini.paymentwallet.repo;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import com.capgemini.paymentwallet.bean.Customer;
import com.capgemini.paymentwallet.bean.Transactions;
import com.capgemini.paymentwallet.bean.Wallet;
import com.capgemini.paymentwallet.util.DBUtil;



import com.capgemini.paymentwallet.exception.InsufficientBalanceException;
import com.capgemini.paymentwallet.exception.InvalidInputException;


public class WalletRepoImpl implements WalletRepo {

	public WalletRepoImpl()
	{
		super();
	}

	@Override
	public boolean save(Customer customer){

		try(Connection con = DBUtil.getConnection()){
			try {

				if(!(customer == findOne(customer.getMobileNo())))
				{PreparedStatement pstm=con.prepareStatement("INSERT INTO Customers VALUES(?,?,?)");

				pstm.setString(1, customer.getName());
				pstm.setString(2, customer.getMobileNo());
				pstm.setBigDecimal(3, customer.getWallet().getBalance());

				pstm.execute();	
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}

		return true;
	}

	@Override
	public Customer findOne(String mobileNo) throws InvalidInputException {
		Customer customer = new Customer();
		try(Connection con = DBUtil.getConnection())
		{

			try
			{
				PreparedStatement pstm=con.prepareStatement("SELECT * FROM Customers WHERE c_mobile_no=?");

				pstm.setString(1,mobileNo);


				ResultSet res=pstm.executeQuery();

				if(res.next()==false)
					throw new InvalidInputException("Your details were not found, Please re-enter your details or register to avail our services.");

				customer=new Customer();

				customer.setName(res.getString(1));
				customer.setMobileNo(res.getString(2));
				customer.setWallet(new Wallet(res.getBigDecimal(3)));
			}

			catch(Exception e)
			{
				e.printStackTrace();
			}

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return customer;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount)
			throws InsufficientBalanceException, InvalidInputException {
		Customer source = withdrawAmount(sourceMobileNo, amount);
		depositAmount(targetMobileNo, amount);

		try(Connection con = DBUtil.getConnection())
		{
			try {

				PreparedStatement ps=con.prepareStatement("INSERT INTO Transactions VALUES(?,?)");

				ps.setString(1,sourceMobileNo);
				ps.setString(2,"Rs"+amount+" was tranfered from your account to " + targetMobileNo);

				ps.execute();

				PreparedStatement ps1=con.prepareStatement("INSERT INTO Transactions VALUES(?,?)");

				ps1.setString(1,targetMobileNo);
				ps1.setString(2, "Rs"+amount+" was transfered to your account from "+sourceMobileNo );

				ps1.execute();

			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return source;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException {
		Customer customer = new Customer();
		try(Connection con = DBUtil.getConnection())
		{
			try
			{
				PreparedStatement pstm=con.prepareStatement("SELECT * FROM Customers WHERE c_mobile_no=?");

				pstm.setString(1, mobileNo);

				ResultSet res = pstm.executeQuery();

				if(res.next()==false)
				{
					System.out.println("Your details were not found, Please re-enter your details or register to avail our services.");
				}

				customer.setName(res.getString(1));
				customer.setMobileNo(res.getString(2));
				customer.setWallet(new Wallet(res.getBigDecimal(3)));

				customer.getWallet().setBalance(customer.getWallet().getBalance().add(amount));

				PreparedStatement pst =con.prepareStatement("UPDATE Customers set c_balance=? where c_mobile_no=?");

				pst.setBigDecimal(1, customer.getWallet().getBalance());
				pst.setString(2, customer.getMobileNo());

				pst.execute();

				PreparedStatement ps = con.prepareStatement("INSERT INTO Transactions VALUES(?,?)");

				ps.setString(1, customer.getMobileNo());
				ps.setString(2, "An amount of Rs " +amount+" was deposited into your wallet.");

				ps.execute();

			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}


		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return customer;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount)
			throws InsufficientBalanceException, InvalidInputException {
		Customer customer = new Customer();

		try(Connection con = DBUtil.getConnection())
		{
			try {

				PreparedStatement pstm=con.prepareStatement("SELECT * FROM Customers WHERE c_mobile_no=?");

				pstm.setString(1, mobileNo);

				ResultSet res = pstm.executeQuery();

				if(res.next()==false)
				{
					System.out.println("Your details were not found, Please re-enter your details or register to avail our services.");
				}

				customer.setName(res.getString(1));
				customer.setMobileNo(res.getString(2));
				customer.setWallet(new Wallet(res.getBigDecimal(3)));

				if(customer.getWallet().getBalance().subtract(amount).compareTo(BigDecimal.ZERO) < 0)
					throw new InsufficientBalanceException("Insufficient Balance to withdraw");
				customer.getWallet().setBalance(customer.getWallet().getBalance().subtract(amount));

				PreparedStatement pst =con.prepareStatement("UPDATE Customers set c_balance=? where c_mobile_no=?");

				pst.setBigDecimal(1, customer.getWallet().getBalance());
				pst.setString(2, customer.getMobileNo());

				pst.execute();

				PreparedStatement ps = con.prepareStatement("INSERT INTO Transactions VALUES(?,?)");

				ps.setString(1, customer.getMobileNo());
				ps.setString(2, "An amount of Rs " +amount+" was withdrawn from your wallet.");

				ps.execute();	

			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return customer;
	}

	@Override
	public List<String> showTransaction(String mobileNo) throws InvalidInputException{

		Customer customer = findOne(mobileNo);
		customer.setTransaction(new Transactions());

		try(Connection con = DBUtil.getConnection())
		{
			try {

				PreparedStatement pstm=con.prepareStatement("SELECT * FROM	 Transactions WHERE c_mobile_no=?");

				pstm.setString(1, mobileNo);

				ResultSet rs=pstm.executeQuery();

				if(rs.next()==false)
					throw new InvalidInputException("No transactions performed.");


				customer.getTransaction().getMessages().add(rs.getString(2));
				while(rs.next())
				{
					customer.getTransaction().getMessages().add(rs.getString(2));
				}
				
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}



		return customer.getTransaction().getMessages();
	}

}


